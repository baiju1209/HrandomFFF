#filename <- 'otu_tree.sh'
#dir <- system.file('data',package='HrandomF.1')
#fullpath <- file.path(dir,filename)#file.path的左右是把两个文件连接在一起得到组合的路径
#fullpath
#library(filesstrings)
#file.move(fullpath,getwd())
OTU_tree=function(p=1){
	filename <- 'otu_tree.sh'
	dir <- system.file('data',package='HrandomF.1')
	fullpath <- file.path(dir,filename)#file.path的左右是把两个文件连接在一起得到组合的路径
	fullpath
	library(filesstrings)
	file.move(fullpath,getwd())
	system(command="bash otu_tree.sh")
	return(p)
}
