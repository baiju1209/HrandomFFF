#' Title
#'
#' @param p
#'
#' @return
#' @export
#'
#' @examples
#filename <- 'Srafastq1.sh'
#dir <- system.file('data',package='HrandomF.1')
#fullpath <- file.path(dir,filename)
#fullpath
#library(filesstrings)
#file.move(fullpath,getwd())
SRAFASTQ=function(p=1){
	filename <- 'Srafastq1.sh'
	dir <- system.file('data',package='HrandomF.1')
	fullpath <- file.path(dir,filename)
	fullpath
	library(filesstrings)
	file.move(fullpath,getwd())
	system(command="bash Srafastq1.sh")
	return(p)
}
