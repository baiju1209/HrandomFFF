site="https://mirrors.tuna.tsinghua.edu.cn/CRAN"
if (!suppressWarnings(suppressMessages(require("optparse", character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))) {
  install.packages("optparse", repos=site)
  require("optparse",character.only=T) 
}

# 显示输入输出确认是否正确
print(paste("The input feature table is ", opts$input,  sep = ""))


package_list <- c("vegan")
for(p in package_list){
  if(!suppressWarnings(suppressMessages(require(p, character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))){
    install.packages(p, repos=site)
    suppressWarnings(suppressMessages(library(p, character.only = TRUE, quietly = TRUE, warn.conflicts = FALSE)))
  }
}



species = read.table(opts$input, header=T, sep="\t", quote = "", row.names=1, comment.char="") 


print(paste0("Samples size are:"))
colSums(species)
min = min(colSums(species))
if (opts$depth==0){
  opts$depth=min}
print(paste("Rarefaction depth ", opts$depth, ". If depth set 0 will using sample minimum size ", min, sep = ""))

print(paste("Random sample number: ", opts$seed,  sep = ""))
set.seed(opts$seed)
otu = vegan::rrarefy(t(species), opts$depth)

idx = rowSums(otu) >= opts$depth

print(paste0("The discard samples: ",rownames(otu[!idx,])))
suppressWarnings(write.table(rownames(otu[!idx,]), file=paste(opts$normalize,".discard",sep=""), append = F, quote = F, sep="\t", eol = "\n", na = "NA", dec = ".", row.names = F, col.names = F))

# 筛选大于抽样数量的样本的特征表
otu = otu[idx,]


# vegan::estimateR计算obs, chao1和ACE指数
estimateR = t(estimateR(otu))[,c(1,2,4)]
colnames(estimateR) = c("richness", "chao1", "ACE")
# vegan::diversity计算多样性指数shannon, simpson和invsimpson
shannon = diversity(otu, index = "shannon")
simpson = diversity(otu, index = "simpson")
invsimpson = diversity(otu, index = "invsimpson")
# 合并6种指数
alpha_div = cbind(estimateR, shannon, simpson, invsimpson)
print(paste0("Calculate six alpha diversities by estimateR and diversity"))
head(alpha_div, n=1)


# 保存一个制表符，解决存在行名时，列名无法对齐的问题
write.table("#OTUID\t", file=paste(opts$normalize,sep=""),append = F, quote = F, eol = "", row.names = F, col.names = F)
# 保存统计结果，有waring正常
suppressWarnings(write.table(t(otu), file=paste(opts$normalize,sep=""), append = T, quote = F, sep="\t", eol = "\n", na = "NA", dec = ".", row.names = T, col.names = T))

# 3.2 保存alpha多样性指数
write.table("SampleID\t", file=paste(opts$output,sep=""),append = F, quote = F, eol = "", row.names = F, col.names = F)
# 保存统计结果，有waring正常
suppressWarnings(write.table(alpha_div, file=paste(opts$output,sep=""), append = T, quote = F, sep="\t", eol = "\n", na = "NA", dec = ".", row.names = T, col.names = T))

print(paste("Name of rarefaction file ", opts$normalize,  sep = ""))
print(paste("Output alpha diversity filename ", opts$output, sep = ""))
print(paste("The discard samples file ",  opts$normalize, ".discard", sep = ""))
