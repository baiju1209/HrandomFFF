group<-read.table('../data/group.txt',sep="\t",header=T,check.names=F)
otutab<-read.table('../data/otutab.txt',sep="\t",header=T,check.names=F)
otutab_1<-read.table('../data/otutab_1.txt',sep="\t",header=T,check.names=F)
metadata<-read.table('../data/metadata.txt',sep="\t",header=T,check.names=F)
