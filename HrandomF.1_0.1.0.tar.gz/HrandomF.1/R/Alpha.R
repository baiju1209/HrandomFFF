library(lattice,lib="E:/R-4.2.0/library")
library(vegan,lib="E:/R-4.2.0/library")
library(estimate,lib="E:/R-4.2.0/library",)
alpha_diversity <- function(x, tree = NULL) {
  observed_species <- estimateR(x)[1, ]
  Chao1 <- estimateR(x)[2, ]
  ACE <- estimateR(x)[4, ]
  Shannon <- diversity(x, index = 'shannon',base = 2)
  Simpson <- diversity(x, index = 'simpson')    #这里是Gini-Simpson 指数
  goods_Coverage <- 1 - rowSums(x == 1) / rowSums(x)

  #保留四位小数
  Shannon <- sprintf("%0.4f", Shannon)
  Simpson <- sprintf("%0.4f", Simpson)
  goods_Coverage <- sprintf("%0.4f", goods_Coverage)


  result <- data.frame(observed_species, ACE,Chao1, Shannon, Simpson, goods_Coverage)

  if (!is.null(tree)) {
    PD_whole_tree <- pd(x, tree, include.root = FALSE)[1]
    names(PD_whole_tree) <- 'PD_whole_tree'
    result <- cbind(result, PD_whole_tree)

    result <- data.frame(observed_species, ACE,Chao1, Shannon, Simpson,
                         PD_whole_tree ,goods_Coverage)
  }


  result
}
#加载OTU 表,可以的话用抽平表
otutab='E:/BYSJ/Rpackage/HrandomF.1/data/otutab.txt'

otu <- read.delim(otutab, row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
otu <- t(otu)
#加载进化树文件
#tree <- read.table('otu_tree.tre')

#如果不需要计算谱系多样性
alpha <- alpha_diversity (otu)

#需要计算谱系多样性时，需要指定进化树文件
#alpha1 <- alpha_diversity (otu, tree)

#将结果输出，保存在本地
write.csv(alpha, 'alpha_diversity.csv', quote = FALSE)
#(alpha1, 'alpha_diversity1.csv', quote = FALSE)
