library(lattice,lib="E:/R-4.2.0/library")
library(vegan,lib="E:/R-4.2.0/library")
library(estimate,lib="E:/R-4.2.0/library",)
#' Title
#'
#' @param x
#' @param tree
#'
#' @return
#' @export
#'
#' @examples
alpha_diversity <- function(otutab, tree = NULL) {
  observed_species <- estimateR(otutab)[1, ]
  Chao1 <- estimateR(otutab)[2, ]
  ACE <- estimateR(otutab)[4, ]
  Shannon <- diversity(otutab, index = 'shannon',base = 2)
  Simpson <- diversity(otutab, index = 'simpson')    #这里是Gini-Simpson 指数
  goods_Coverage <- 1 - rowSums(otutab == 1) / rowSums(otutab)
  #保留四位小数
  Shannon <- sprintf("%0.4f", Shannon)
  Simpson <- sprintf("%0.4f", Simpson)
  goods_Coverage <- sprintf("%0.4f", goods_Coverage)
  result <- data.frame(observed_species, ACE,Chao1, Shannon, Simpson, goods_Coverage)
  if (!is.null(tree)) {
    PD_whole_tree <- pd(otutab, tree, include.root = FALSE)[1]
    names(PD_whole_tree) <- 'PD_whole_tree'
    result <- cbind(result, PD_whole_tree)

    result <- data.frame(observed_species, ACE,Chao1, Shannon, Simpson,
                         PD_whole_tree ,goods_Coverage)
  }
  result
}

otutab='E:/BYSJ/Rpackage/HrandomF.1/data/otutab.txt'
otu <- read.delim(otutab, row.names = 1, sep = '\t', stringsAsFactors = FALSE, check.names = FALSE)
otu <- t(otu)
alpha <- alpha_diversity (otu)
write.csv(alpha, 'alpha_diversity.csv', quote = FALSE)

