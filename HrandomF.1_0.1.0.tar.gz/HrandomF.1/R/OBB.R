# otu_train.forest下err.rate中是OOB的数据，它有三列，分别是总OOB、分组1的OOB以及分组2的OOB
# 创建数据框用于ggplot绘图
oob.error.data <- data.frame(
  Trees=rep(1:nrow(otu_train.select.forest$err.rate), times=3),
  Type=rep(c("OOB", "HSL", "HHM"), each=nrow(otu_train.forest$err.rate)),
  Error=c(otu_train.forest$err.rate[,"OOB"],
          otu_train.forest$err.rate[,"HSL"],
          otu_train.forest$err.rate[,"HHM"]))
# 绘图
ggplot(oob.error.data, aes(x=Trees, y=Error)) + geom_line(aes(color=Type))
