design = read.table("metadata.txt", header=T, row.names= 1, sep="\t") 
otu_table = read.delim("otutab.txt", row.names= 1,  header=T, sep="\t")
otu_table <- otu_table[which(rowSums(otu_table,na.rm = TRUE,)>=100),]
idx = rownames(design) %in% colnames(otu_table) 
sub_design = design[idx,]
count = otu_table[, rownames(sub_design)]
norm = t(t(count)/colSums(count,na=T)) * 100 
# normalization to total 100
# 计算所有样品间相关系数
sim=cor(norm,method="pearson")
library("gplots")
library("RColorBrewer")
pdf(file=paste("heat_cor_samples.pdf", sep=""), height = 8, width = 8)
heatmap.2(sim, Rowv=TRUE, Colv=TRUE, dendrogram='both', trace='none', margins=c(6,6), col=rev(colorRampPalette(brewer.pal(11, "RdYlGn"))(256)),density.info="none") 
dev.off()

