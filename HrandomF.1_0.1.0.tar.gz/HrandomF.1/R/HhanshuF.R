#' @title HDR
#' @description BALABALA,BALABA
#' @details Input AND output
#' @param x A a data.
#' @param W The size.
#' @return A list
#' @export
#' @import
#' @importFrom
#' @examples


#记得设置工作目录
#setwd("dir")

#内置的数据，需要处理自己的数据的话记得换路径
#数据预处理
#读取 OTUs 丰度表
#设置工作目录
library(randomForest)
library(reshape2)
library(ggplot2)
library(pROC)

setwd("data")


group="group.txt"               #输入分组信息
conFile="otutab.txt"             #训练集otu组
treatFile="otutab_1.txt"           #预测集otu组

otu <- read.table(conFile,row.names = 1,header=T)
otu1 <- read.table(treatFile,row.names = 1,header=T)

#过滤低丰度 OTUs 类群，它们对分类贡献度低，且影响计算效率
#otu和被预测otu中剔除总丰度低于100 的值

data_clean=function(otu,otu1,Top,group,Trees){
	otu <- otu[which(rowSums(otu,na.rm = TRUE,)>=Top),]
	otu1 <- otu1[which(rowSums(otu1,na.rm = TRUE,)>=Top),]
	name=intersect(row.names(otu),row.names(otu1))
	otu=otu[name,]
	otu1=otu1[name,]
	#合并有关物种的信息
	plant <- read.table(group, row.names = 1,header=T)
	otu <- data.frame(t(otu))
	#otu <- otu[rownames(plant), ]
	otu <- cbind(otu, plant)
	otu_train <- otu
	otu_train$group=factor(otu_train$group)
	otu1 <- data.frame(t(otu1))
##randomForest 包的随机森林
	set.seed(500)
	otu_train.forest <- randomForest(group~., data = otu_train, importance = TRUE,ntree = Trees)
	return(otu_train.forest)
}

#' Title
#'
#' @param otu_train.forest
#' @param top
#'
#' @return
#' @export
#'
#' @examples

Importance_otuP=function(otu_train.forest,top,index){
	importance_otu <- otu_train.forest$importance
	head(importance_otu)
#作图展示
	varImpPlot(otu_train.forest, n.var = min(top, nrow(otu_train.forest$importance)),
           main = 'variable importance')
	importance_otu <- importance_otu[order(importance_otu[,index], decreasing = TRUE), ]
	write.table(importance_otu, 'importance_otu.txt', sep = '\t', col.names = NA, quote = FALSE)
	return(importance_otu)
}

##交叉验证辅助评估选择特定数量的 OTU
#重复十折交叉验证
RandomFJCYZ=function(otu_train,replay){
	set.seed(300)
	otu_train.cv <- replicate(replay, rfcv(otu_train[-ncol(otu_train)], otu_train$group, cv.fold = 10, step = 1.5), simplify = FALSE)
	otu_train.cv <- data.frame(sapply(otu_train.cv, '[[', 'error.cv'))
	otu_train.cv$otus <- rownames(otu_train.cv)
	otu_train.cv <- reshape2::melt(otu_train.cv, id = 'otus')
	otu_train.cv$otus <- as.numeric(as.character(otu_train.cv$otus))
	otu_train.cv.mean <- aggregate(otu_train.cv$value, by = list(otu_train.cv$otus),FUN = mean)
	return(otu_train.cv.mean)
}

Select_PicOTU=function(otu_train.cv,Top){
	p=ggplot(otu_train.cv, aes(Group.1, x)) +
	geom_line() +
	theme(panel.grid = element_blank(), panel.background = element_rect(color = 'black', fill = 'transparent')) +
	labs(title = '',x = 'Number of OTUs', y = 'Cross-validation error')
	p=p+geom_vline(aes(xintercept=Top), colour="#BB0000", linetype="dashed")
	p
#取出排名靠前的 OTU
	importance_otu.select <- importance_otu[1:Top, ]
	importance_otu.select
#输出表格
	write.table(importance_otu.select, 'importance_otu.select.txt', sep = '\t', col.names	 = NA, quote = FALSE)
	return(p)
}

ImotumatchPic=function(rf,taxonomy,top){
	a=as.data.frame(round(importance(rf), 2))
	a$id=row.names(a)
	a2<- dplyr::arrange(a, desc(MeanDecreaseAccuracy))
	row.names(a2)=a2$id
	a3=head(a2,n=top)
	taxonomy <- as.data.frame(taxonomy)
	tax = taxonomy[rownames(a3),]
	a3 = merge(a3,tax,by = "row.names",all = F)
	row.names(a3) = a3$Row.names
	a3$Row.names = NULL
	p1 <- ggplot(a3, aes(x = MeanDecreaseAccuracy, y = reorder(id,MeanDecreaseAccuracy))) +
	 geom_point(size=6,pch=top,fill = "blue")+
	 geom_segment(aes(yend=id),xend=0,size=3)+
	 geom_label(aes(x =MeanDecreaseAccuracy*1.1, label = Family),size = 3)
	return(p1)
}


# otu_train.forest下err.rate中是OOB的数据，它有三列，分别是总OOB、分组1的OOB以及分组2的OOB
# 创建数据框用于ggplot绘图
oob_errorPic=function(forest,p=1){
	oob.error.data <- data.frame(
	Trees=rep(1:nrow(forest$err.rate), times=3),
	Type=rep(c("OOB", "HSL", "HHM"), each=nrow(forest$err.rate)),
	Error=c(forest$err.rate[,"OOB"],
			forest$err.rate[,"HSL"],
			forest$err.rate[,"HHM"]))
# 绘图
	g=ggplot(oob.error.data, aes(x=Trees, y=Error)) + geom_line(aes(color=Type))
	return(g)
}

#	model <- randomForest(factor(groupset)~., data = dataset, importance = TRUE)
	
pROCpic=function(dataset,group){
	fc<-as.numeric()
	mod_pre<-as.numeric()
	model <- randomForest(factor(group)~., data = dataset, importance = TRUE)
	model_pre<-predict(model,type="prob")
	fc<-append(fc,as.numeric(ifelse(dataset$group=="HHM",0,1)))
	mod_pre<-append(mod_pre,model_pre[,1])
	df<-cbind(fc,as.numeric(mod_pre))
# ROC曲线
	x<-plot.roc(df[,1],df[,2],
            smooth=T,
            lwd=2,
            ylim=c(0,1),
            xlim=c(1,0),
            legacy.axes=T,
            main="",
            col="seagreen3")
	x[["auc"]]
	legend.name <- c("Area under the curve")
	legend("bottomright",
	       legend=legend.name,
	       lwd = 2,
	       col = "seagreen3",
	       bty="n")	
	return(x[["auc"]])
}
#输出预测文件
#t=predict(model,newdata=otu1)
#write.table(t,"predict.txt")



