system(command="bash data/srafastq.sh")
