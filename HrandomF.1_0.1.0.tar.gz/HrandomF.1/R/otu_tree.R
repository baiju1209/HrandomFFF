system(command="bash data/otu_tree.sh")

