#   db=/E/BYSJ/EasyMicrobiome-main
#   ea=/E/BYSJ/EasyAmplicon-master/EasyAmplicon-master
#	 wd=E:/BYSJ/Rpackage/HrandomF.1/data/sra
#	 cd ${wd}
#wget https://ftp-trace.ncbi.nlm.nih.gov/s
	#如果没有SRAtoolkit工具，下载一个ra/sdk/2.11.3/sratoolkit.2.11.3-ubuntu64.tar.gz
	#解压
#tar -xzvf sratoolkit.2.11.3-ubuntu64.tar.gz
	#进入解压文件中的bin进行配置
	#设置路径
#export PATH=$PATH:$PWD/sratoolkit.2.11.3-ubuntu64/bin
	#配置环境
#vdb-config --interactive
	#将所有sra文件，转化为fastq.gz文件
	#进入存放sra文件的目录
	fastq-dump --split-3 *.sra
	mkdir sra
	mv *.sra sra
	gzip -r *.fastq

    mkdir -p temp
    mkdir -p result
  	mkdir -p result/alpha
    cp metadata.txt result

	#记得提前准备好metadata文件
	#测序结果是双端的
	for i in `tail -n+2 metadata.txt | cut -f 1`;do
	  vsearch -fastq_mergepairs ${i}_1.fastq.gz \
	 -reverse ${i}_2.fastq.gz \
	 -fastqout temp/${i}.merged.fq -relabel ${i}.
	done
	cat temp/*.merged.fq > temp/all.fq
	#切除引物
	time vsearch --fastx_filter temp/all.fq \
	  --fastq_stripleft 18 --fastq_stripright 20 \
	  --fastq_maxee_rate 0.01 \
	  --fastaout temp/filtered.fa
	#去冗余
	vsearch --derep_fulllength temp/filtered.fa \
	  --minuniquesize 1 --sizeout --relabel Uni_ \
	  --output temp/uniques.fa
	#聚类otu
	usearch -unoise3 temp/uniques.fa -minsize 10 \
	  -zotus temp/zotus.fa
	 #修改序列名
	sed 's/Zotu/ASV_/g' temp/zotus.fa > temp/otus.fa

	mkdir -p result/raw

	 #去嵌合
	vsearch --uchime_ref temp/otus.fa \
	  -db ${db}/usearch/rdp_16s_v18.fa \
	  --nonchimeras result/raw/otus.fa
	sed -i 's/\r//g' result/raw/otus.fa
	#生产OTU特征表
	time vsearch --usearch_global temp/filtered.fa \
	  --db result/raw/otus.fa \
	  --id 0.97 --threads 4 \
	  --otutabout result/raw/otutab.txt
	  cp result/raw/otutab.txt result/otutab.txt
	sed -i 's/\r//' result/otutab.txt
	
	#物种注释
	vsearch --sintax result/raw/otus.fa \
	  --db ${db}/usearch/rdp_16s_v18.fa \
	  --sintax_cutoff 0.1 \
	  --tabbedout result/raw/otus.sintax --sintax_cutoff 0.6
	sed -i 's/\r//' result/otus.sintax
	#获得抽平表otutab_rare.txt,和alpha多样性vegan.txt
	Rscript ${db}/script/otutab_rare.R --input result/otutab.txt \
	  --depth 10000 --seed 1 \
	  --normalize result/otutab_rare.txt \
	  --output result/alpha/vegan.txt
	usearch -otutab_stats result/otutab_rare.txt \
	  -output result/otutab_rare.stat

	#物种注释汇总
	cut -f 1,4 result/raw/otus.sintax \
	  |sed 's/\td/\tk/;s/:/__/g;s/,/;/g;s/"//g' \
	  > result/taxonomy2.txt
	#OTU对应物种8列格式：注意注释是非整齐
	#生成物种表格OTU/ASV中空白补齐为Unassigned
	  awk 'BEGIN{OFS=FS="\t"}{delete a; a["k"]="Unassigned";a["p"]="Unassigned";a["c"]="Unassigned";a["o"]="Unassigned";a["f"]="Unassigned";a["g"]="Unassigned";a["s"]="Unassigned";\
	   split($2,x,";");for(i in x){split(x[i],b,"__");a[b[1]]=b[2];} \
	   print $1,a["k"],a["p"],a["c"],a["o"],a["f"],a["g"],a["s"];}' \
	   result/taxonomy2.txt > temp/otus.tax
	  sed 's/;/\t/g;s/.__//g;' temp/otus.tax|cut -f 1-8 | \
	  sed '1 s/^/OTUID\tKingdom\tPhylum\tClass\tOrder\tFamily\tGenus\tSpecies\n/' \
	   > result/taxonomy.txt

rm -rf temp/*.fq

